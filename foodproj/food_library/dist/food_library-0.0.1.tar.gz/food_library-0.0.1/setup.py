from setuptools import setup, find_packages

setup(
    name='food_library',
    version="0.0.1",
    packages=find_packages(),
    install_requires=[
        # Add dependencies here.    
        # e.g. 'numphy>=1.11.1'
    ],
)